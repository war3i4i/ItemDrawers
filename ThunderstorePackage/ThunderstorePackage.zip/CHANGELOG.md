1.1.1
- New patch fix

1.1.0
- New patch fix

1.0.9
- New patch fix

1.0.8
- Ashlands

1.0.7
- ItemExclude config now works on any item, even on equipable one (can now exclude arrows, for example)

1.0.6
- Added options UI when you crouch + interact
- Added DefaultColor + MaxDrawerPickupRange settings 

1.0.5
- Added new drawer styles: Panel_Wood, Panel_Stone, Panel_Marble, NoModel
- Fixed API issues

1.0.4
- Now old Makail's drawers are auto-converted into this mod wooden drawers

1.0.3
- Added API

1.0.2
- Optimizations

1.0.1
- Small fixes

1.0.0
- Init release
