![](https://i.imgur.com/6tMijPp.png)

A rework of ItemDrawers mod. Has same features (auto pickup, get stack, get one item, put item from hotbar, put all similar items from inventory). Has 3 variants of drawers: wood, stone, marble

Like my mods? Support me: `war3spells@gmail.com` (Paypal)



####  Questions or Comments, find KG in the Odin Plus Discord:
[![https://i.imgur.com/XXP6HCU.png](https://i.imgur.com/XXP6HCU.png)](https://discord.gg/5gXNxNkUBt)